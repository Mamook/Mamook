-- phpMyAdmin SQL Dump
-- version 4.3.11.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 09, 2015 at 12:55 PM
-- Server version: 5.6.23
-- PHP Version: 5.4.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jamtheforce`
--

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
CREATE TABLE IF NOT EXISTS `content` (
  `id` mediumint(8) unsigned NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `hide_title` tinyint(1) unsigned DEFAULT NULL COMMENT '0=Hide Title, NULL=Don''t Hide Title',
  `content` longtext NOT NULL,
  `quote` text NOT NULL COMMENT 'Optional quote to display on page.',
  `topic` text NOT NULL COMMENT 'For the "page-topic" meta tag.',
  `image` varchar(255) DEFAULT NULL,
  `image_title` varchar(255) DEFAULT NULL,
  `sub_domain` varchar(255) DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL COMMENT 'NULL if not currently assigned to a page',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `archive` tinyint(1) unsigned DEFAULT NULL COMMENT 'NULL=Not Archived 0=Archived',
  `social` tinyint(1) DEFAULT NULL COMMENT 'NULL=Don''t use Social buttons 0=Use social buttons'
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `page_title`, `sub_title`, `hide_title`, `content`, `quote`, `topic`, `image`, `image_title`, `sub_domain`, `page`, `date`, `archive`, `social`) VALUES
(1, '%{site_name}', NULL, NULL, '', '', '', NULL, NULL, NULL, 'index.php', '2010-07-12 21:29:02', NULL, NULL),
(2, 'Administration', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/index.php', '2010-07-28 08:07:06', NULL, NULL),
(3, 'Videos', NULL, NULL, '', '', '', NULL, NULL, NULL, 'media/videos/index.php', '2010-07-29 19:56:58', NULL, NULL),
(4, 'Search', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/index.php', '2010-07-29 20:15:19', NULL, NULL),
(5, 'Login or Register', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/index.php', '2010-07-29 20:23:51', NULL, NULL),
(6, 'Policy Statment', NULL, NULL, 'When you access the web site, you agree to the terms of the Privacy Policy, as outlined below. If you do not agree to these terms, please do not access or use this site. %{site_name} reserves the right to change the Online Privacy Policy from time-to-time at its sole discretion. Your use of this site will be subject to the most current version of the %{site_name} Online Privacy Policy at the time of such use.In the paragraphs below we discuss our approach to<ul><li><a href="#_Collection_of_personal">collecting personal information</a> and</li><li><a href="#_How_your_personal">how your personal information</a> is used.</li></ul>We, furthermore, discuss<ul><li><a href="#_Your_choices_with">your choices with respect to personal information</a> and</li><li><a href="#_Protection_of_your">the steps we take to protect your personal information</a>.</li></ul>Finally, we discuss<ul><li><a href="#_Use_of_cookies">the use of "cookies</a>" and</li><li> <a href="#_Updating_your_personal">ways that you may update your personal information</a></li></ul><h3 id="_Collection_of_personal">Collection of personal information</h3>When you engage in certain activities on this site, such as ordering, registering, downloading documents or replying to surveys, %{site_name} may ask you to provide certain information about yourself by filling out and submitting an online form. It is completely optional for you to engage in these activities. If you elect to engage in these activities, however, the Center for World Indigenous Studies may ask that you provide us personal information, such as your first and last name, mailing address, e-mail address, your professional title, telephone and facsimile numbers, and other personal identifying information. When ordering %{site_name} publications or services on the site, you may be asked to provide a credit card number. Depending upon the activity, some of the information that we ask you to provide is identified as mandatory and some as voluntary. If you do not provide the mandatory data with respect to a particular activity, you will not be able to engage in that activity. Our server is secure for credit card transactions.When you submit personal information to the Center for World Indigenous Studies on this site, you understand and agree that this information may be transferred across national boundaries and may be stored and processed in any of the countries in which the Center for World Indigenous Studies, its affiliates and subsidiaries maintain offices, including without limitation, the United States of America. You also acknowledge that in certain countries or with respect to certain activities, the collection, transferring, storage and processing of your information may be undertaken by trusted vendors of the %{site_name}<h3 id="_How_your_personal">How your personal information is used</h3>%{site_name} collects information provided by you in order to record and support your participation in the activities you select. If you order a publication or service that is to be electronically transmitted, for example, the information is used to register your license and rights.<h3 id="_Your_choices_with">Your choices with respect to personal information</h3>%{site_name} recognizes and appreciates the importance of responsible use of information collected on this site. If you do not want the information you provide to %{site_name} to be used to inform you of other products, services and event notifications, and you indicate this preference when you provide your personal information to %{site_name}, %{site_name} will honor your preference.<h3 id="_Protection_of_your">Protection of your personal information</h3>The personal information that you provide in connection with registering yourself as a %{site_name} user or registering for a %{site_name} product is classified as Registration Information. Registration Information is protected in several ways. Your Registration Information resides on a secure server. %{site_name} encrypts your personal information and thereby prevents unauthorized parties from viewing such information when it is transmitted to %{site_name}. Personal information that you provide that is not Registration Information also resides on a secure server. Since this information is not accessible from outside the Center for World Indigenous Studies, you will not be asked to select a password in order to view or modify such information.Please note that any information you post to a public bulletin board or chat room, such as the %{site_name} User to User Forums, is available to all persons accessing that site.<h3 id="_Use_of_cookies">Use of cookies</h3>When you visit %{domain_name}, you can surf the site anonymously and access important information without revealing your identity. %{domain_name} uses cookies. A cookie is small amount of data that is transferred to your browser by a Web server and can only be read by the server that gave it to you. It functions as your identification card, that reminds the server that you are logged in and of your preferences. It cannot be executed as code or deliver viruses.Most browsers are initially set to accept cookies. You can set your browser to notify you when you receive a cookie, giving you the chance to decide whether or not to accept it. (For some aspects of this website to work correctly, cookies are not optional. Users choosing not to accept cookies will probably not view a fully functional website, and may not be able to access some content.)Please note that any information you post to a public bulletin board or chat room, such as the %{site_name} User to User Forums, is available to all persons accessing that site.<h3 id="_Updating_your_personal">Updating your personal information</h3>You have the right to correct your personal information at any time.Please log in to your account and go to <a href="https://%{domain_name}/secure/MyAccount/">MyAccount</a>. There, you may update your personal information, change privacy settings, and more. We subscribe to online practices protecting personal information and appreciate your visit.', '', '', NULL, NULL, NULL, 'policy/index.php', '2010-07-29 20:58:06', NULL, NULL),
(7, 'Web Support', NULL, NULL, '', '', '', NULL, NULL, NULL, 'webSupport/index.php', '2010-07-29 21:01:01', NULL, NULL),
(8, 'Site Map', NULL, NULL, '', '', '', NULL, NULL, NULL, 'SiteMap/index.php', '2010-07-29 21:03:06', NULL, NULL),
(9, 'Change Password', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/change_password.php', '2010-10-08 23:56:32', NULL, NULL),
(10, 'Register', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/register/index.php', '2010-07-29 21:29:34', NULL, NULL),
(11, 'Resend My Activation Email', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/ResendEmail/index.php', '2010-07-29 21:45:42', NULL, NULL),
(12, 'Lost Password', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/LostPassword/index.php', '2010-07-29 21:49:55', NULL, NULL),
(13, 'Registration Confirmation', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/confirm.php', '2010-07-29 21:49:55', NULL, NULL),
(14, 'There Seems to Have Been an Error...', NULL, NULL, '<p>There was an error processing your request. Please be assured that the webmaster has been notified of the error and will take steps to repair it as soon  as possible.</p><p>If you would like to send the Webmaster an email describing the error and the circumstances that resulted in the error, please use the form below.</p><p>Thank you.</p>', '', '', NULL, NULL, NULL, 'error/index.php', '2010-07-31 16:11:19', NULL, NULL),
(15, 'Contact Us', NULL, NULL, '', '', '', NULL, NULL, NULL, 'contact/index.php', '2010-08-02 14:58:00', NULL, NULL),
(16, 'Manage Content', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/index.php', '2011-06-21 17:10:27', NULL, NULL),
(17, 'Test Page', NULL, NULL, '', '', '', NULL, NULL, NULL, 'test.php', '2010-08-23 22:34:50', NULL, NULL),
(18, 'Audio', NULL, NULL, '', '', '', NULL, NULL, NULL, 'media/audio/index.php', '2010-08-29 18:36:03', NULL, NULL),
(19, 'Announcements', NULL, NULL, '', '', '', NULL, NULL, NULL, 'announcement/index.php', '2010-09-03 17:50:09', NULL, NULL),
(20, '400 - Bad Request', NULL, NULL, 'Your request could not be completed. Please check that the URL is properly formed. Using the links on this webpage, you may find the information you seek.Thank you for your patience.', '', '', NULL, NULL, NULL, 'error/400.php', '2010-10-08 21:09:27', NULL, NULL),
(21, '403 - Forbidden', NULL, NULL, 'There is no access to the URL you requested. Perhaps there was an error in the URL? Using the links on this webpage, you may find the information you seek.', '', '', NULL, NULL, NULL, 'error/403.php', '2010-10-08 21:09:27', NULL, NULL),
(22, '404 - Page Not Found', NULL, NULL, 'The page you were looking for cannot be found. Perhaps there was an error in the URL? Using the links on this webpage you may be able to find the information you were looking for.', '', '', NULL, NULL, NULL, 'error/404.php', '2010-10-08 21:10:09', NULL, NULL),
(23, '500 - Internal Error', NULL, NULL, 'There was an error on our side of things. Be assured that we will do our best to repair the problem as soon as possible. Please try again. If the error persists, please give us a little time to address the error and then you may try agian.Thank you for your patience.', '', '', NULL, NULL, NULL, 'error/500.php', '2010-10-08 21:10:09', NULL, NULL),
(24, 'Change Username', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/change_username.php', '2010-10-08 23:41:19', NULL, NULL),
(25, 'Manage Users', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/index.php', '2010-10-08 23:43:53', NULL, NULL),
(26, 'User Privacy', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/privacy.php', '2014-09-20 23:12:53', NULL, NULL),
(27, 'Change Username', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/change_username.php', '2010-10-08 23:56:32', NULL, NULL),
(28, 'Delete Account', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/delete.php', '2010-10-08 23:56:32', NULL, NULL),
(29, 'Privacy Settings', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/privacy.php', '2010-10-08 23:56:32', NULL, NULL),
(30, 'Profile', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/index.php', '2010-10-08 23:56:32', NULL, NULL),
(31, 'Request Authorization', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/authorizations.php', '2010-10-09 00:03:28', NULL, NULL),
(32, 'Profile', NULL, NULL, '', '', '', NULL, NULL, NULL, 'profile/index.php', '2010-10-09 17:20:16', NULL, NULL),
(35, 'Frequently Asked Questions', NULL, NULL, '<ul><li><h3>How do I register?</h3><ol><li>To register for the site, simply go to <a href="https://%{domain_name}/secure/login/register/" title="Register at %{domain_name}">https://%{domain_name}/secure/login/register/</a>.</li><li>Choose and enter a username.</li><li>Enter your email address.</li><li>Choose and enter a password.</li><li>Complete the ReCaptcha field (if it us difficult to make out the letters, you may reload new ones or opt to hear them.)</li><li>Now click the "register" button.</li><li>You should receive a confirmation email at the address you provided containing an activation link. Click the link in the email (or copy it and paste it into your browser) and you are fully registered and ready to go!</li></ol></li><li><h3>I am having troubles logging in</h3><ol><li>If you are having trouble logging into the site, please click <a href="https://%{domain_name}/secure/login/logout/">here</a> and then attempt to log in again.</li><li>If the first solution did not remedy the login trouble, please send an email to our web support describing the problem in detail and the steps taken. You may use the form at the <a href="http://%{domain_name}/webSupport/">webSupport page</a>.</li></ol></li></ul>', '', '', NULL, NULL, NULL, 'webSupport/FAQ.php', '2010-11-20 01:03:47', NULL, NULL),
(36, 'Opt-Out / Opt-In', NULL, NULL, 'To opt-out or opt-in for receiving email messages (Newsletter) from %{site_name}, simply <a href="https://%{domain_name}/secure/login/" title="Login to %{domain_name}">login</a> to your account and go to <a href="https://%{domain_name}/secure/MyAccount/privacy.php" title="Your Privacy Settings">https://%{domain_name}/secure/MyAccount/privacy.php</a>. If you have any questions or concerns about our <a href="http://%{domain_name}/policy/" title="Privacy Policy">privacy policy</a>, please contact us.', '', '', NULL, NULL, NULL, 'policy/OptOut.php', '2011-01-22 05:34:09', NULL, NULL),
(37, 'Policy Dispute', NULL, NULL, 'If you have any questions or concerns about our <a href="http://%{domain_name}/policy/">privacy policy</a>, please contact us using one of the methods below.', '', '', NULL, NULL, NULL, 'policy/dispute.php', '2011-01-22 05:41:57', NULL, NULL),
(56, 'Language Management', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/languages/index.php', '2013-12-10 05:26:39', NULL, NULL),
(38, 'Announcement Mangament', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/announcement/index.php', '2013-12-10 03:44:27', NULL, NULL),
(41, 'Manage Media', 'Audio', NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageMedia/audio/index.php', '2011-06-29 22:34:00', NULL, NULL),
(39, 'Manage Media', NULL, NULL, 'Use the menu to the left to navigate to the media you would like to manage.', '', '', NULL, NULL, NULL, 'secure/admin/ManageMedia/index.php', '2011-06-29 22:33:41', NULL, NULL),
(40, 'Manage Media', 'Images', NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageMedia/images/index.php', '2011-06-29 22:33:41', NULL, NULL),
(42, 'Manage Media', 'Videos', NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageMedia/videos/index.php', '2011-06-29 22:34:20', NULL, NULL),
(43, 'Manage Media', 'Files', NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageMedia/files/index.php', '2011-06-29 22:34:39', NULL, NULL),
(44, 'Email Users', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/EmailUsers/index.php', '2011-11-22 15:41:45', NULL, NULL),
(45, 'Change Password', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/change_password.php', '2011-12-13 18:12:59', NULL, NULL),
(46, 'Authorize User', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/authorize_user.php', '2011-12-13 18:25:15', NULL, NULL),
(47, 'Delete User', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/delete_user.php', '2011-12-13 18:51:13', NULL, NULL),
(48, 'Logging Out', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/logout/index.php', '2012-02-28 15:52:26', NULL, NULL),
(49, 'To PayPal!', NULL, NULL, 'You are being redirected to the PayPal&trade; website. Please be patient...', '', '', NULL, NULL, NULL, 'secure/PayPal.php', '2012-03-02 22:49:30', NULL, NULL),
(51, 'Social Feeds', NULL, NULL, '', '', '', NULL, NULL, NULL, 'social/index.php', '2012-03-09 19:38:17', NULL, NULL),
(50, 'Publisher', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/publishers/index.php', '2012-04-02 17:39:41', NULL, NULL),
(52, 'Sending Email', NULL, NULL, 'Please do not close this window until the email has finished sending.', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/EmailUsers/sending_email.php', '2012-06-11 17:18:21', NULL, NULL),
(54, 'Manage Content', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/content/index.php', '2013-04-09 03:19:04', NULL, NULL),
(55, 'Institution Management', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/institutions/index.php', '2013-12-10 05:26:39', NULL, NULL),
(57, 'Products', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/products/index.php', '2014-03-09 18:48:54', NULL, NULL),
(58, 'Store', NULL, NULL, '', '', '', NULL, NULL, NULL, 'store/index.php', '2010-07-27 21:47:41', NULL, NULL),
(59, 'Store', NULL, NULL, '', '', '', NULL, NULL, NULL, 'store/books/index.php', '2010-08-29 23:11:17', NULL, NULL),
(60, 'Search', NULL, NULL, '', '', '', NULL, NULL, NULL, 'search/index.php', '2014-10-07 18:20:55', NULL, NULL),
(33, 'Update Staff Profile', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/staff_profile.php', '2015-03-09 12:50:08', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`), ADD KEY `page` (`page`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
