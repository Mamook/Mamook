-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 06, 2015 at 05:56 AM
-- Server version: 5.6.25
-- PHP Version: 5.4.42

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jamtheforce`
--

-- --------------------------------------------------------

--
-- Table structure for table `audio`
--

DROP TABLE IF EXISTS `audio`;
CREATE TABLE IF NOT EXISTS `audio` (
  `id` int(9) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL COMMENT 'The description o',
  `file_name` varchar(255) DEFAULT NULL,
  `embed_code` text,
  `api` longtext,
  `author` text,
  `year` year(4) DEFAULT NULL,
  `playlist` varchar(64) NOT NULL DEFAULT '-6-' COMMENT 'The id''s of the playlists from the categories table separated by a dash(-)',
  `availability` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Do we have the legal rights to display this material? 1=Yes 0=Not yet 2=Internal document only 3=Can not distribute',
  `date` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Date originally posted',
  `image` mediumint(10) unsigned DEFAULT NULL,
  `institution` smallint(5) unsigned NOT NULL DEFAULT '9' COMMENT 'The id of the institution from the institutions table',
  `publisher` mediumint(8) unsigned DEFAULT NULL COMMENT 'The id of the publisher from the publishers table',
  `language` smallint(5) unsigned NOT NULL DEFAULT '3' COMMENT 'The id of the language from the languages tablege for the entry',
  `contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `recent_contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `last_edit` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Date of the last edit by recent_contributor',
  `new` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
CREATE TABLE IF NOT EXISTS `branches` (
  `id` smallint(4) unsigned NOT NULL,
  `branch` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL DEFAULT '%{domain_name}' COMMENT 'The domain name for the branch'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `branch`, `domain`) VALUES
(50, 'Announcement', '%{domain_name}/announcement'),
(60, 'Video', '%{domain_name}/media/videos'),
(70, 'Audio', '%{domain_name}/media/audio');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` smallint(5) unsigned NOT NULL,
  `name` varchar(75) NOT NULL,
  `api` longtext
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `api`) VALUES
(1, 'Books', NULL),
(2, 'Maps', NULL),
(3, 'Subscription', NULL),
(4, 'Donation', NULL),
(5, 'Music', '{"site_audio":"1"}'),
(6, 'General', NULL),
(26, 'Nonprofits & Activism', '{"YouTube":{category_id":"29"}}'),
(7, 'Related Sites', NULL),
(8, 'Report', NULL),
(9, 'Periodical', NULL),
(10, 'Pamphlet', NULL),
(11, 'Memorandum', NULL),
(12, 'Letters', NULL),
(13, 'United Nations', NULL),
(14, 'Speech', NULL),
(15, 'Scholastic Paper', NULL),
(16, 'Fun', NULL),
(17, 'Resources', NULL),
(18, 'Flag', NULL),
(19, 'Seal', NULL),
(20, 'Logo', NULL),
(21, 'Convention', NULL),
(22, 'Top Picks', NULL),
(23, 'Recommended', NULL),
(24, 'Publications', NULL),
(25, 'Education', '{"YouTube":{category_id":"27"}}'),
(36, 'Videos', '{"site_video":"1"}'),
(37, 'Audio', '{"site_audio":"1"}');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) unsigned NOT NULL,
  `video` varchar(75) NOT NULL,
  `user` mediumint(8) unsigned DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `content` text NOT NULL,
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `id` smallint(5) unsigned NOT NULL,
  `site_name` varchar(255) NOT NULL,
  `slogan` text NOT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `registration` tinyint(1) unsigned DEFAULT NULL,
  `archive` tinyint(1) unsigned DEFAULT '0',
  `maintenance` tinyint(1) unsigned DEFAULT NULL COMMENT 'NULL=No 0=Maintenance mode'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `site_name`, `slogan`, `address1`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `email`, `registration`, `archive`, `maintenance`) VALUES
(1, 'Jam The Force', 'Framework', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'info@jamtheforce.com', NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
CREATE TABLE IF NOT EXISTS `content` (
  `id` mediumint(8) unsigned NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `hide_title` tinyint(1) unsigned DEFAULT NULL COMMENT '0=Hide Title, NULL=Don''t Hide Title',
  `content` longtext NOT NULL,
  `quote` text NOT NULL COMMENT 'Optional quote to display on page.',
  `topic` text NOT NULL COMMENT 'For the "page-topic" meta tag.',
  `image` varchar(255) DEFAULT NULL,
  `image_title` varchar(255) DEFAULT NULL,
  `sub_domain` varchar(255) DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL COMMENT 'NULL if not currently assigned to a page',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `archive` tinyint(1) unsigned DEFAULT NULL COMMENT 'NULL=Not Archived 0=Archived',
  `social` tinyint(1) DEFAULT NULL COMMENT 'NULL=Don''t use Social buttons 0=Use social buttons',
  `api` longtext
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `page_title`, `sub_title`, `hide_title`, `content`, `quote`, `topic`, `image`, `image_title`, `sub_domain`, `page`, `date`, `archive`, `social`, `api`) VALUES
(1, '%{site_name}', NULL, NULL, '', '', '', NULL, NULL, NULL, 'index.php', '2010-07-12 21:29:02', NULL, NULL, NULL),
(2, 'Administration', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/index.php', '2010-07-28 08:07:06', NULL, NULL, NULL),
(3, 'Videos', NULL, NULL, '', '', '', NULL, NULL, NULL, 'media/videos/index.php', '2010-07-29 19:56:58', NULL, NULL, NULL),
(4, 'Search', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/index.php', '2010-07-29 20:15:19', NULL, NULL, NULL),
(5, 'Login or Register', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/index.php', '2010-07-29 20:23:51', NULL, NULL, NULL),
(6, 'Policy Statment', NULL, NULL, 'When you access the web site, you agree to the terms of the Privacy Policy, as outlined below. If you do not agree to these terms, please do not access or use this site. %{site_name} reserves the right to change the Online Privacy Policy from time-to-time at its sole discretion. Your use of this site will be subject to the most current version of the %{site_name} Online Privacy Policy at the time of such use.In the paragraphs below we discuss our approach to<ul><li><a href="#_Collection_of_personal">collecting personal information</a> and</li><li><a href="#_How_your_personal">how your personal information</a> is used.</li></ul>We, furthermore, discuss<ul><li><a href="#_Your_choices_with">your choices with respect to personal information</a> and</li><li><a href="#_Protection_of_your">the steps we take to protect your personal information</a>.</li></ul>Finally, we discuss<ul><li><a href="#_Use_of_cookies">the use of "cookies</a>" and</li><li> <a href="#_Updating_your_personal">ways that you may update your personal information</a></li></ul><h3 id="_Collection_of_personal">Collection of personal information</h3>When you engage in certain activities on this site, such as ordering, registering, downloading documents or replying to surveys, %{site_name} may ask you to provide certain information about yourself by filling out and submitting an online form. It is completely optional for you to engage in these activities. If you elect to engage in these activities, however, the Center for World Indigenous Studies may ask that you provide us personal information, such as your first and last name, mailing address, e-mail address, your professional title, telephone and facsimile numbers, and other personal identifying information. When ordering %{site_name} publications or services on the site, you may be asked to provide a credit card number. Depending upon the activity, some of the information that we ask you to provide is identified as mandatory and some as voluntary. If you do not provide the mandatory data with respect to a particular activity, you will not be able to engage in that activity. Our server is secure for credit card transactions.When you submit personal information to the Center for World Indigenous Studies on this site, you understand and agree that this information may be transferred across national boundaries and may be stored and processed in any of the countries in which the Center for World Indigenous Studies, its affiliates and subsidiaries maintain offices, including without limitation, the United States of America. You also acknowledge that in certain countries or with respect to certain activities, the collection, transferring, storage and processing of your information may be undertaken by trusted vendors of the %{site_name}<h3 id="_How_your_personal">How your personal information is used</h3>%{site_name} collects information provided by you in order to record and support your participation in the activities you select. If you order a publication or service that is to be electronically transmitted, for example, the information is used to register your license and rights.<h3 id="_Your_choices_with">Your choices with respect to personal information</h3>%{site_name} recognizes and appreciates the importance of responsible use of information collected on this site. If you do not want the information you provide to %{site_name} to be used to inform you of other products, services and event notifications, and you indicate this preference when you provide your personal information to %{site_name}, %{site_name} will honor your preference.<h3 id="_Protection_of_your">Protection of your personal information</h3>The personal information that you provide in connection with registering yourself as a %{site_name} user or registering for a %{site_name} product is classified as Registration Information. Registration Information is protected in several ways. Your Registration Information resides on a secure server. %{site_name} encrypts your personal information and thereby prevents unauthorized parties from viewing such information when it is transmitted to %{site_name}. Personal information that you provide that is not Registration Information also resides on a secure server. Since this information is not accessible from outside the Center for World Indigenous Studies, you will not be asked to select a password in order to view or modify such information.Please note that any information you post to a public bulletin board or chat room, such as the %{site_name} User to User Forums, is available to all persons accessing that site.<h3 id="_Use_of_cookies">Use of cookies</h3>When you visit %{domain_name}, you can surf the site anonymously and access important information without revealing your identity. %{domain_name} uses cookies. A cookie is small amount of data that is transferred to your browser by a Web server and can only be read by the server that gave it to you. It functions as your identification card, that reminds the server that you are logged in and of your preferences. It cannot be executed as code or deliver viruses.Most browsers are initially set to accept cookies. You can set your browser to notify you when you receive a cookie, giving you the chance to decide whether or not to accept it. (For some aspects of this website to work correctly, cookies are not optional. Users choosing not to accept cookies will probably not view a fully functional website, and may not be able to access some content.)Please note that any information you post to a public bulletin board or chat room, such as the %{site_name} User to User Forums, is available to all persons accessing that site.<h3 id="_Updating_your_personal">Updating your personal information</h3>You have the right to correct your personal information at any time.Please log in to your account and go to <a href="https://%{domain_name}/secure/MyAccount/">MyAccount</a>. There, you may update your personal information, change privacy settings, and more. We subscribe to online practices protecting personal information and appreciate your visit.', '', '', NULL, NULL, NULL, 'policy/index.php', '2010-07-29 20:58:06', NULL, NULL, NULL),
(7, 'Web Support', NULL, NULL, '', '', '', NULL, NULL, NULL, 'webSupport/index.php', '2010-07-29 21:01:01', NULL, NULL, NULL),
(8, 'Site Map', NULL, NULL, '', '', '', NULL, NULL, NULL, 'SiteMap/index.php', '2010-07-29 21:03:06', NULL, NULL, NULL),
(9, 'Change Password', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/change_password.php', '2010-10-08 23:56:32', NULL, NULL, NULL),
(10, 'Register', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/register/index.php', '2010-07-29 21:29:34', NULL, NULL, NULL),
(11, 'Resend My Activation Email', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/ResendEmail/index.php', '2010-07-29 21:45:42', NULL, NULL, NULL),
(12, 'Lost Password', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/LostPassword/index.php', '2010-07-29 21:49:55', NULL, NULL, NULL),
(13, 'Registration Confirmation', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/confirm.php', '2010-07-29 21:49:55', NULL, NULL, NULL),
(14, 'There Seems to Have Been an Error...', NULL, NULL, '<p>There was an error processing your request. Please be assured that the webmaster has been notified of the error and will take steps to repair it as soon  as possible.</p><p>If you would like to send the Webmaster an email describing the error and the circumstances that resulted in the error, please use the form below.</p><p>Thank you.</p>', '', '', NULL, NULL, NULL, 'error/index.php', '2010-07-31 16:11:19', NULL, NULL, NULL),
(15, 'Contact Us', NULL, NULL, '', '', '', NULL, NULL, NULL, 'contact/index.php', '2010-08-02 14:58:00', NULL, NULL, NULL),
(16, 'Manage Content', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/index.php', '2011-06-21 17:10:27', NULL, NULL, NULL),
(17, 'Test Page', NULL, NULL, '', '', '', NULL, NULL, NULL, 'test.php', '2010-08-23 22:34:50', NULL, NULL, NULL),
(18, 'Audio', NULL, NULL, '', '', '', NULL, NULL, NULL, 'media/audio/index.php', '2010-08-29 18:36:03', NULL, NULL, NULL),
(19, 'Announcements', NULL, NULL, '', '', '', NULL, NULL, NULL, 'announcement/index.php', '2010-09-03 17:50:09', NULL, NULL, NULL),
(20, '400 - Bad Request', NULL, NULL, 'Your request could not be completed. Please check that the URL is properly formed. Using the links on this webpage, you may find the information you seek.Thank you for your patience.', '', '', NULL, NULL, NULL, 'error/400.php', '2010-10-08 21:09:27', NULL, NULL, NULL),
(21, '403 - Forbidden', NULL, NULL, 'There is no access to the URL you requested. Perhaps there was an error in the URL? Using the links on this webpage, you may find the information you seek.', '', '', NULL, NULL, NULL, 'error/403.php', '2010-10-08 21:09:27', NULL, NULL, NULL),
(22, '404 - Page Not Found', NULL, NULL, 'The page you were looking for cannot be found. Perhaps there was an error in the URL? Using the links on this webpage you may be able to find the information you were looking for.', '', '', NULL, NULL, NULL, 'error/404.php', '2010-10-08 21:10:09', NULL, NULL, NULL),
(23, '500 - Internal Error', NULL, NULL, 'There was an error on our side of things. Be assured that we will do our best to repair the problem as soon as possible. Please try again. If the error persists, please give us a little time to address the error and then you may try agian.Thank you for your patience.', '', '', NULL, NULL, NULL, 'error/500.php', '2010-10-08 21:10:09', NULL, NULL, NULL),
(24, 'Change Username', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/change_username.php', '2010-10-08 23:41:19', NULL, NULL, NULL),
(25, 'Manage Users', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/index.php', '2010-10-08 23:43:53', NULL, NULL, NULL),
(26, 'User Privacy', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/privacy.php', '2014-09-20 23:12:53', NULL, NULL, NULL),
(27, 'Change Username', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/change_username.php', '2010-10-08 23:56:32', NULL, NULL, NULL),
(28, 'Delete Account', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/delete.php', '2010-10-08 23:56:32', NULL, NULL, NULL),
(29, 'Privacy Settings', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/privacy.php', '2010-10-08 23:56:32', NULL, NULL, NULL),
(30, 'Profile', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/index.php', '2010-10-08 23:56:32', NULL, NULL, NULL),
(31, 'Request Authorization', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/authorizations.php', '2010-10-09 00:03:28', NULL, NULL, NULL),
(32, 'Profile', NULL, NULL, '', '', '', NULL, NULL, NULL, 'profile/index.php', '2010-10-09 17:20:16', NULL, NULL, NULL),
(35, 'Frequently Asked Questions', NULL, NULL, '<ul><li><h3>How do I register?</h3><ol><li>To register for the site, simply go to <a href="https://%{domain_name}/secure/login/register/" title="Register at %{domain_name}">https://%{domain_name}/secure/login/register/</a>.</li><li>Choose and enter a username.</li><li>Enter your email address.</li><li>Choose and enter a password.</li><li>Complete the ReCaptcha field (if it us difficult to make out the letters, you may reload new ones or opt to hear them.)</li><li>Now click the "register" button.</li><li>You should receive a confirmation email at the address you provided containing an activation link. Click the link in the email (or copy it and paste it into your browser) and you are fully registered and ready to go!</li></ol></li><li><h3>I am having troubles logging in</h3><ol><li>If you are having trouble logging into the site, please click <a href="https://%{domain_name}/secure/login/logout/">here</a> and then attempt to log in again.</li><li>If the first solution did not remedy the login trouble, please send an email to our web support describing the problem in detail and the steps taken. You may use the form at the <a href="http://%{domain_name}/webSupport/">webSupport page</a>.</li></ol></li></ul>', '', '', NULL, NULL, NULL, 'webSupport/FAQ.php', '2010-11-20 01:03:47', NULL, NULL, NULL),
(36, 'Opt-Out / Opt-In', NULL, NULL, 'To opt-out or opt-in for receiving email messages (Newsletter) from %{site_name}, simply <a href="https://%{domain_name}/secure/login/" title="Login to %{domain_name}">login</a> to your account and go to <a href="https://%{domain_name}/secure/MyAccount/privacy.php" title="Your Privacy Settings">https://%{domain_name}/secure/MyAccount/privacy.php</a>. If you have any questions or concerns about our <a href="http://%{domain_name}/policy/" title="Privacy Policy">privacy policy</a>, please contact us.', '', '', NULL, NULL, NULL, 'policy/OptOut.php', '2011-01-22 05:34:09', NULL, NULL, NULL),
(37, 'Policy Dispute', NULL, NULL, 'If you have any questions or concerns about our <a href="http://%{domain_name}/policy/">privacy policy</a>, please contact us using one of the methods below.', '', '', NULL, NULL, NULL, 'policy/dispute.php', '2011-01-22 05:41:57', NULL, NULL, NULL),
(56, 'Language Management', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/languages/index.php', '2013-12-10 05:26:39', NULL, NULL, NULL),
(38, 'Announcement Mangament', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/announcement/index.php', '2013-12-10 03:44:27', NULL, NULL, NULL),
(41, 'Manage Media', 'Audio', NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageMedia/audio/index.php', '2011-06-29 22:34:00', NULL, NULL, NULL),
(39, 'Manage Media', NULL, NULL, 'Use the menu to the left to navigate to the media you would like to manage.', '', '', NULL, NULL, NULL, 'secure/admin/ManageMedia/index.php', '2011-06-29 22:33:41', NULL, NULL, NULL),
(40, 'Manage Media', 'Images', NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageMedia/images/index.php', '2011-06-29 22:33:41', NULL, NULL, NULL),
(42, 'Manage Media', 'Videos', NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageMedia/videos/index.php', '2011-06-29 22:34:20', NULL, NULL, NULL),
(43, 'Manage Media', 'Files', NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageMedia/files/index.php', '2011-06-29 22:34:39', NULL, NULL, NULL),
(44, 'Email Users', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/EmailUsers/index.php', '2011-11-22 15:41:45', NULL, NULL, NULL),
(45, 'Change Password', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/change_password.php', '2011-12-13 18:12:59', NULL, NULL, NULL),
(46, 'Authorize User', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/authorize_user.php', '2011-12-13 18:25:15', NULL, NULL, NULL),
(47, 'Delete User', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/delete_user.php', '2011-12-13 18:51:13', NULL, NULL, NULL),
(48, 'Logging Out', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/login/logout/index.php', '2012-02-28 15:52:26', NULL, NULL, NULL),
(49, 'To PayPal!', NULL, NULL, 'You are being redirected to the PayPal&trade; website. Please be patient...', '', '', NULL, NULL, NULL, 'secure/PayPal.php', '2012-03-02 22:49:30', NULL, NULL, NULL),
(51, 'Social Feeds', NULL, NULL, '', '', '', NULL, NULL, NULL, 'social/index.php', '2012-03-09 19:38:17', NULL, NULL, NULL),
(50, 'Publisher', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/publishers/index.php', '2012-04-02 17:39:41', NULL, NULL, NULL),
(52, 'Sending Email', NULL, NULL, 'Please do not close this window until the email has finished sending.', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/EmailUsers/sending_email.php', '2012-06-11 17:18:21', NULL, NULL, NULL),
(54, 'Manage Content', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/content/index.php', '2013-04-09 03:19:04', NULL, NULL, NULL),
(55, 'Institution Management', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/institutions/index.php', '2013-12-10 05:26:39', NULL, NULL, NULL),
(57, 'Products', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageContent/products/index.php', '2014-03-09 18:48:54', NULL, NULL, NULL),
(58, 'Store', NULL, NULL, '', '', '', NULL, NULL, NULL, 'store/index.php', '2010-07-27 21:47:41', NULL, NULL, NULL),
(59, 'Store', NULL, NULL, '', '', '', NULL, NULL, NULL, 'store/books/index.php', '2010-08-29 23:11:17', NULL, NULL, NULL),
(60, 'Search', NULL, NULL, '', '', '', NULL, NULL, NULL, 'search/index.php', '2014-10-07 18:20:55', NULL, NULL, NULL),
(33, 'Update Staff Profile', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/MyAccount/staff_profile.php', '2015-03-09 12:50:08', NULL, NULL, NULL),
(34, 'Update Staff Profile', NULL, NULL, '', '', '', NULL, NULL, NULL, 'secure/admin/ManageUsers/staff_profile.php', '2015-03-09 12:50:08', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contributors`
--

DROP TABLE IF EXISTS `contributors`;
CREATE TABLE IF NOT EXISTS `contributors` (
  `id` mediumint(8) unsigned NOT NULL,
  `fname` tinytext NOT NULL,
  `lname` tinytext,
  `email` varchar(100) DEFAULT NULL,
  `ip` varbinary(16) DEFAULT NULL COMMENT 'Encoded with INET6_ATON() if MySQL 5.6.3+. Otherwise, INET_ATON()',
  `region` tinytext,
  `country` varchar(100) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `privacy` tinyint(1) unsigned DEFAULT '0' COMMENT 'NULL=Hidden 0=Not Hidden 1=Users Only',
  `user` int(10) unsigned DEFAULT NULL COMMENT 'NULL=Not User Value=User ID'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contributors`
--

INSERT INTO `contributors` (`id`, `fname`, `lname`, `email`, `ip`, `region`, `country`, `organization`, `privacy`, `user`) VALUES
(1, 'JTF', NULL, 'info@jamtheforce.com', NULL, NULL, 'United States', 'JTF', 0, NULL),
(2, '', NULL, 'webmaster@jamtheforce.com', NULL, NULL, NULL, NULL, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
CREATE TABLE IF NOT EXISTS `files` (
  `id` int(9) unsigned NOT NULL,
  `title` text NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `author` text,
  `year` year(4) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `category` varchar(64) NOT NULL DEFAULT '-6-' COMMENT 'The id''s of the categories from the categories table separated by a dash(-)',
  `availability` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Do we have the legal rights to display this material? 1=Yes 0=Not yet 2=Internal document only 3=Can not distribute',
  `date` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Date originally posted',
  `premium` tinyint(1) unsigned DEFAULT NULL COMMENT 'NULL=Not Premium Content 0=Premium Content',
  `institution` smallint(5) unsigned NOT NULL DEFAULT '9' COMMENT 'The id of the institution from the institutions table',
  `publisher` mediumint(8) unsigned DEFAULT NULL COMMENT 'The id of the publisher from the publishers table',
  `language` smallint(5) unsigned NOT NULL DEFAULT '3' COMMENT 'The id of the language from the languages tablege for the entry',
  `contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `recent_contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `last_edit` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Date of the last edit by recent_contributor'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `description` text,
  `location` text,
  `category` varchar(64) NOT NULL DEFAULT '-6-' COMMENT 'The id(s) of the category(ies) from the categories table separated by a dash(-)',
  `image` varchar(255) NOT NULL,
  `hide` tinyint(1) unsigned DEFAULT '0' COMMENT 'NULL=Hidden 0=Not Hidden',
  `contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `recent_contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `last_edit` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Date of last edit by recent_contributor'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `title`, `description`, `location`, `category`, `image`, `hide`, `contributor`, `recent_contributor`, `last_edit`) VALUES
(1, 'Audio Default Thumbnail', NULL, NULL, '-6-', 'audio-default-thumbnail.jpg', 0, NULL, NULL, '0000-00-00'),
(2, 'Default Avatar', NULL, NULL, '-6-', 'default-avatar.png', 0, NULL, NULL, '0000-00-00'),
(3, 'No Image Available', 'Amazon''s default image if the image is not found.', NULL, '-1-', 'no.image.available.gif', 0, NULL, NULL, '0000-00-00'),
(4, 'Not Found', NULL, NULL, '-6-', 'notfound.jpg', 0, NULL, NULL, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `institutions`
--

DROP TABLE IF EXISTS `institutions`;
CREATE TABLE IF NOT EXISTS `institutions` (
  `id` smallint(5) unsigned NOT NULL,
  `institution` varchar(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `institutions`
--

INSERT INTO `institutions` (`id`, `institution`) VALUES
(1, 'Business / Corporation'),
(2, 'Indigenous Government'),
(3, 'Newspaper'),
(4, 'Non-Governmental Organization'),
(5, 'Religious Organization'),
(6, 'State Government'),
(7, 'University'),
(9, 'Other'),
(10, 'International Organization');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `id` smallint(5) unsigned NOT NULL,
  `language` varchar(255) NOT NULL,
  `ISO` varchar(2) DEFAULT NULL COMMENT 'The ISO Code for the language'
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `language`, `ISO`) VALUES
(1, 'Arabic', 'ar'),
(2, 'Bengali', 'bn'),
(3, 'English', 'en'),
(4, 'Chinese', 'zh'),
(5, 'Hindi', 'hi'),
(6, 'Spanish', 'es'),
(7, 'Russian', 'ru'),
(21, 'French', 'fr'),
(9, 'Portuguese', 'pt'),
(10, 'Malay', 'ms'),
(11, 'Japanese', 'ja'),
(12, 'German', 'de'),
(13, 'Urdu', 'ur'),
(14, 'Italian', 'it'),
(15, 'Korean', 'ko'),
(16, 'Vietnamese', 'vi'),
(17, 'Tagalog', 'tl'),
(18, 'Thai', 'th'),
(19, 'Turkish', 'tr'),
(22, 'Other', NULL),
(20, 'Persian', 'fa');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `ID` int(10) unsigned NOT NULL,
  `user_ID` int(10) unsigned NOT NULL,
  `txnid` varchar(255) NOT NULL,
  `payer_id` varchar(255) NOT NULL,
  `txn_type` varchar(255) NOT NULL,
  `item_number` varchar(255) NOT NULL,
  `payer_email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `country_code` varchar(10) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `residence` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(9) NOT NULL,
  `option_name1` varchar(255) NOT NULL,
  `option_selection1` varchar(255) NOT NULL,
  `option_name2` varchar(255) NOT NULL,
  `option_selection2` varchar(255) NOT NULL,
  `payment_currency` varchar(10) NOT NULL,
  `settle_currency` varchar(10) NOT NULL,
  `exchange_rate` varchar(255) NOT NULL,
  `shipping` float(8,2) NOT NULL DEFAULT '0.00',
  `payment_gross` float(8,2) NOT NULL,
  `payment_fee` float(8,2) NOT NULL,
  `settle_amount` float(8,2) NOT NULL,
  `memo` varchar(255) NOT NULL,
  `payment_date` varchar(256) NOT NULL,
  `pending_reason` varchar(256) NOT NULL,
  `reason_code` varchar(256) NOT NULL,
  `creation_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 PACK_KEYS=1 COMMENT='Orders';

-- --------------------------------------------------------

--
-- Table structure for table `orders_cart`
--

DROP TABLE IF EXISTS `orders_cart`;
CREATE TABLE IF NOT EXISTS `orders_cart` (
  `ID` int(10) unsigned NOT NULL,
  `user_ID` int(10) unsigned NOT NULL,
  `txnid` varchar(255) NOT NULL,
  `payer_id` varchar(255) NOT NULL,
  `item_number` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(9) NOT NULL,
  `option_name1` varchar(255) NOT NULL,
  `option_selection1` varchar(255) NOT NULL,
  `option_name2` varchar(255) NOT NULL,
  `option_selection2` varchar(255) NOT NULL,
  `payment_date` varchar(255) NOT NULL,
  `creation_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Orders from Shopping Cart';

-- --------------------------------------------------------

--
-- Table structure for table `playlists`
--

DROP TABLE IF EXISTS `playlists`;
CREATE TABLE IF NOT EXISTS `playlists` (
  `id` smallint(5) unsigned NOT NULL,
  `name` varchar(75) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `api` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `playlists`
--

INSERT INTO `playlists` (`id`, `name`, `api`) VALUES
(1, 'Books', NULL),
(2, 'Maps', NULL),
(5, 'Music', '{"site_audio":"1"}'),
(6, 'General', '{"YouTube":{playlist_id":"PLZMGBw-fSgEKORkRbPHS16c8Z86kU8XPv"}}'),
(7, 'Related Sites', NULL),
(8, 'Report', NULL),
(9, 'Periodical', NULL),
(10, 'Pamphlet', NULL),
(11, 'Memorandum', NULL),
(12, 'Letters', NULL),
(13, 'United Nations', NULL),
(14, 'Speech', NULL),
(15, 'Scholastic Paper', NULL),
(16, 'Fun', NULL),
(17, 'Resources', NULL),
(18, 'Flag', NULL),
(19, 'Seal', NULL),
(21, 'Convention', NULL),
(22, 'Top Picks', NULL),
(23, 'Recommended', NULL),
(24, 'Publications', NULL),
(25, 'Pacific', '{"YouTube":{playlist_id":"PL1E9452D0A9D89FA1}}'),
(26, 'NW Indian News', '{"YouTube":{playlist_id":"PL4665D3F12359EE07"}}'),
(27, 'American Indian', '{"YouTube":{playlist_id":"PLD2D6E64D9CD49E10"}}'),
(28, 'Africa', '{"YouTube":{playlist_id":"PL0349E54856B3C13C"}}'),
(29, 'User Submissions', '{"youtube_playlist_id":"PL3F224999715E7118","site_video":"1"}'),
(30, 'Interviews', '{"youtube_playlist_id":"PL987B84EC2F27E7B1","site_video":"1"}'),
(31, 'Entertainment', '{"youtube_playlist_id":"PLF81D96EC51EEB4DE","site_video":"1"}'),
(32, 'Conferences', '{"youtube_playlist_id":"PL8947202619E28ACB","site_video":"1"}'),
(33, 'Chronicles', '{"youtube_playlist_id":"PLA10B84379007A820","site_video":"1"}'),
(34, 'South East Asia', '{"youtube_playlist_id":"PL9538E6F241E28FF4","site_video":"1"}'),
(35, 'Asia', '{"youtube_playlist_id":"PLD1D5E6226C209033","site_video":"1"}'),
(36, 'Videos', '{"site_video":"1"}'),
(37, 'Audio', '{"site_audio":"1"}'),
(38, 'Tutorials', '{"youtube_playlist_id":"PLZMGBw-fSgEK7_J9YYKSHpV2DoWlr8tbp","site_video":"1"}'),
(39, 'Spotlight Audio', '{"site_audio":"1"}');

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
CREATE TABLE IF NOT EXISTS `positions` (
  `id` smallint(4) unsigned NOT NULL,
  `position` varchar(255) NOT NULL,
  `description` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` mediumint(8) unsigned NOT NULL,
  `category` varchar(64) NOT NULL COMMENT 'The id(s) of the category(ies) from the categories table separated by a dash(-)',
  `sort_by` int(10) unsigned DEFAULT NULL COMMENT 'NULL=ListAll 1=TopPicks 2=Recommend 3=Publications 4=General',
  `ASIN` text COMMENT 'NULL=Not an Amazon Product VALUE=The Amazon product ID(ASIN)',
  `price` decimal(5,2) DEFAULT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'USD' COMMENT 'USD, CAD, GBP, EUR, JPY',
  `button_id` text,
  `image` int(10) unsigned DEFAULT NULL COMMENT 'The id of the image from the images table',
  `title` text NOT NULL,
  `author` varchar(100) DEFAULT NULL,
  `publisher` mediumint(8) unsigned DEFAULT NULL COMMENT 'The id of the publisher from the publishers table',
  `description` text,
  `content` text,
  `purchase_link` text,
  `link` text,
  `file` int(9) unsigned DEFAULT NULL COMMENT 'NULL=No File Value=The id of the file from the files table'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `publishers`
--

DROP TABLE IF EXISTS `publishers`;
CREATE TABLE IF NOT EXISTS `publishers` (
  `id` mediumint(8) unsigned NOT NULL,
  `date` date NOT NULL DEFAULT '0000-00-00',
  `name` varchar(255) NOT NULL,
  `info` text COMMENT 'Info about the publisher',
  `contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `recent_contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `last_edit` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Date of last edit by recent_contributor'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `publishers`
--

INSERT INTO `publishers` (`id`, `date`, `name`, `info`, `contributor`, `recent_contributor`, `last_edit`) VALUES
(1, '2014-09-22', 'YouTube.com', NULL, 1, NULL, '0000-00-00'),
(2, '2014-09-22', 'Facebook', 'Facebook is an online social network at <a title="The Facebook Website" href="http://www.facebook.com/" target="_blank">http://www.facebook.com</a>', 1, NULL, '0000-00-00'),
(3, '2014-09-22', 'Twitter', 'Twitter is an online social network at <a title="The Twitter Website" href="http://www.twitter.com/" target="_blank">http://www.twitter.com</a>', 1, NULL, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `social`
--

DROP TABLE IF EXISTS `social`;
CREATE TABLE IF NOT EXISTS `social` (
  `id` smallint(5) unsigned NOT NULL,
  `name` varchar(75) NOT NULL,
  `code` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `active` tinyint(1) DEFAULT NULL COMMENT 'NULL=Not Active 1=Active'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `social`
--

INSERT INTO `social` (`id`, `name`, `code`, `url`, `image`, `active`) VALUES
(1, 'Facebook', '<span id="facebook"><a href="http://www.facebook.com/sharer.php" onclick="return fbs_click()" target="_blank"><img src="http://%{domain_name}/images/social/facebook_icon.png" alt="Share on Facebook" /></a></span>', 'http://www.facebook.com/sharer.php?u=', 'facebook_icon.png', 1),
(2, 'Twitter', '<span id="twitter">\r\n  <a href="http://twitter.com/share" target="_blank" class="twitter-button" id="twitter-button"><span id="custom-tweet-button"></span></a>\r\n</span>', 'http://twitter.com/share?url=', 'twitter_icon.png', 1),
(3, 'Google Buzz', '<span id="google">\r\n<a title="Post to Google Buzz" class="google-buzz-button" href="http://www.google.com/buzz/post" data-button-style="small-button"></a>\r\n<script type="text/javascript" src="http://www.google.com/buzz/api/button.js"></script>\r\n</span>', 'http://www.google.com/buzz/post?url=', 'google_icon.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `id` mediumint(8) unsigned NOT NULL,
  `title` varchar(80) DEFAULT NULL,
  `fname` varchar(80) NOT NULL,
  `mname` varchar(80) DEFAULT NULL,
  `lname` varchar(80) NOT NULL,
  `credentials` varchar(50) DEFAULT NULL,
  `region` varchar(50) DEFAULT NULL,
  `affiliation` text,
  `position` longtext NOT NULL,
  `image_title` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL DEFAULT 'default-avatar.png',
  `text` text,
  `user` int(10) unsigned DEFAULT NULL,
  `archive` tinyint(1) unsigned DEFAULT NULL COMMENT 'NULL=Not Archived 0=Archived'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `subcontent`
--

DROP TABLE IF EXISTS `subcontent`;
CREATE TABLE IF NOT EXISTS `subcontent` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `file` int(9) unsigned DEFAULT NULL COMMENT 'The id of the file from the files table',
  `availability` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Do we have the legal rights to display this material? 1=Yes 0=Not yet 2=Internal document only 3=Can not distribute',
  `visibility` varchar(64) DEFAULT NULL COMMENT 'NULL=Visible to all 0=Visible to members only Value=dash separated user access levels',
  `date` date NOT NULL DEFAULT '0000-00-00',
  `premium` tinyint(1) unsigned DEFAULT NULL COMMENT 'NULL=Not Premium Content 0=Premium Content',
  `branch` varchar(64) NOT NULL DEFAULT '-' COMMENT 'Dash sepparated branch values',
  `institution` smallint(5) unsigned NOT NULL DEFAULT '9' COMMENT 'The id of the institution from the institutions table',
  `publisher` mediumint(8) unsigned DEFAULT NULL COMMENT 'The id of the publisher from the publishers table',
  `text_language` smallint(5) unsigned DEFAULT NULL COMMENT 'The id of the language for the entry from the languages table',
  `text` text,
  `trans_language` smallint(5) unsigned DEFAULT NULL COMMENT 'The id of the language for the entry from the languages table',
  `text_trans` text COMMENT 'The translation for text.',
  `hide` tinyint(1) unsigned DEFAULT NULL COMMENT 'NULL=Not Hidden 0=Hidden',
  `audio` mediumint(10) unsigned DEFAULT NULL,
  `image` mediumint(10) unsigned DEFAULT NULL COMMENT 'The id of the image from the images table',
  `video` mediumint(10) unsigned DEFAULT NULL,
  `contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `recent_contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `last_edit` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Date of last edit by recent_contributor'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

DROP TABLE IF EXISTS `themes`;
CREATE TABLE IF NOT EXISTS `themes` (
  `id` mediumint(8) unsigned NOT NULL,
  `default` tinyint(1) unsigned DEFAULT NULL COMMENT '0=Default Theme, NULL=Not In Use',
  `name` varchar(255) NOT NULL,
  `designer` varchar(255) DEFAULT NULL COMMENT 'The person or organization that developed the design.',
  `website` varchar(255) DEFAULT NULL COMMENT 'The website of the designer.'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `default`, `name`, `designer`, `website`) VALUES
(1, 0, 'default', 'BigTalk Jon R&yuml;ser', 'JonRyser.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(10) unsigned NOT NULL,
  `staff_id` int(10) unsigned DEFAULT NULL,
  `display` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2-',
  `title` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `fname` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `lname` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `region` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `address` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `address2` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `city` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `state` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `country` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `phone` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `img` varchar(75) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default-avatar.png' COMMENT 'User Image',
  `img_title` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'The title for the user image',
  `password` varbinary(256) NOT NULL,
  `interests` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `bio` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cv` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `organization` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `newsletter` tinyint(1) unsigned DEFAULT '0' COMMENT '0=Receive Newsletter NULL=Don''t Receive Newsletter',
  `notify` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Branch id=Notify Member NULL=Don''t Notify Member',
  `questions` tinyint(1) unsigned DEFAULT NULL COMMENT '0=Accept Questions NULL=Don''t Accept Questions',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0=Not Activated 1=Activated 2=Suspended',
  `subscription` date DEFAULT NULL,
  `product` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `random` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `registered` date NOT NULL DEFAULT '0000-00-00',
  `reg_ip` varbinary(16) DEFAULT NULL COMMENT 'Encoded with INET6_ATON() if MySQL 5.6.3+. Otherwise, INET_ATON()',
  `lastlogin` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='User information';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `staff_id`, `display`, `username`, `level`, `title`, `fname`, `lname`, `email`, `region`, `address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `img`, `img_title`, `password`, `interests`, `bio`, `cv`, `organization`, `website`, `newsletter`, `notify`, `questions`, `active`, `subscription`, `product`, `random`, `registered`, `reg_ip`, `lastlogin`) VALUES
(2, NULL, 'admin', 'admin', '-1-', NULL, NULL, NULL, 'webmaster@jamtheforce.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default-avatar.png', NULL, 0x7a484d316e4d524778564a61647576697132696255696a6f62484b427636554747667a655a542b684653673d, NULL, '', NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 'L3WOf1d7VV4YD1nHLusbUuXqRnZqAQjm', '2015-03-09', NULL, '2015-05-19');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(9) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text COMMENT 'The description o',
  `file_name` varchar(255) DEFAULT NULL,
  `embed_code` text,
  `api` longtext,
  `author` text,
  `year` year(4) DEFAULT NULL,
  `playlist` varchar(64) NOT NULL DEFAULT '-6-' COMMENT 'The id''s of the playlists from the categories table separated by a dash(-)',
  `availability` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Do we have the legal rights to display this material? 1=Yes 0=Not yet 2=Internal document only 3=Can not distribute',
  `date` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Date originally posted',
  `image` mediumint(10) unsigned DEFAULT NULL,
  `institution` smallint(5) unsigned NOT NULL DEFAULT '9' COMMENT 'The id of the institution from the institutions table',
  `publisher` mediumint(8) unsigned DEFAULT NULL COMMENT 'The id of the publisher from the publishers table',
  `language` smallint(5) unsigned NOT NULL DEFAULT '3' COMMENT 'The id of the language from the languages tablege for the entry',
  `contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `recent_contributor` mediumint(8) unsigned DEFAULT NULL COMMENT 'NULL=Not Available Value=Contributor ID',
  `last_edit` date NOT NULL DEFAULT '0000-00-00' COMMENT 'Date of the last edit by recent_contributor',
  `new` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audio`
--
ALTER TABLE `audio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contributor` (`contributor`),
  ADD KEY `file` (`file_name`),
  ADD KEY `title` (`title`),
  ADD KEY `image` (`image`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `branch` (`branch`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category` (`name`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `page` (`page`);

--
-- Indexes for table `contributors`
--
ALTER TABLE `contributors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user` (`user`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contributor` (`contributor`),
  ADD KEY `file` (`file`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `image` (`image`);

--
-- Indexes for table `institutions`
--
ALTER TABLE `institutions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `institution` (`institution`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `language` (`language`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_ID` (`user_ID`),
  ADD KEY `payer_id` (`payer_id`),
  ADD KEY `txnid` (`txnid`);

--
-- Indexes for table `orders_cart`
--
ALTER TABLE `orders_cart`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_ID` (`user_ID`),
  ADD KEY `payer_id` (`payer_id`),
  ADD KEY `txnid` (`txnid`);

--
-- Indexes for table `playlists`
--
ALTER TABLE `playlists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category` (`name`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `position` (`position`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `publishers`
--
ALTER TABLE `publishers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contributor` (`contributor`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `social`
--
ALTER TABLE `social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcontent`
--
ALTER TABLE `subcontent`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contributor` (`contributor`),
  ADD KEY `file` (`file`),
  ADD KEY `image` (`image`),
  ADD KEY `title` (`title`),
  ADD KEY `branch` (`branch`),
  ADD KEY `audio` (`audio`),
  ADD KEY `video` (`video`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contributor` (`contributor`),
  ADD KEY `file` (`file_name`),
  ADD KEY `image` (`image`),
  ADD KEY `title` (`title`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audio`
--
ALTER TABLE `audio`
  MODIFY `id` int(9) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
  MODIFY `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `contributors`
--
ALTER TABLE `contributors`
  MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(9) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `institutions`
--
ALTER TABLE `institutions`
  MODIFY `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `ID` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders_cart`
--
ALTER TABLE `orders_cart`
  MODIFY `ID` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `playlists`
--
ALTER TABLE `playlists`
  MODIFY `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `publishers`
--
ALTER TABLE `publishers`
  MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `social`
--
ALTER TABLE `social`
  MODIFY `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `subcontent`
--
ALTER TABLE `subcontent`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(9) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
